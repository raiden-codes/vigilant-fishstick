
    // Function to update the name-email message
    function updateNameEmailMessage() {
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const messageElement = document.getElementById('name-email-message');

      if (name) {
        messageElement.textContent = `Your name email is: ${name}${email ? ' ' + email : ''}`;
        messageElement.classList.remove('hidden');
      } else {
        messageElement.classList.add('hidden');
      }
    }

    // Event listener for name input
    document.getElementById('name').addEventListener('input', updateNameEmailMessage);

    // Event listener for email input to update message if email changes
    document.getElementById('email').addEventListener('input', updateNameEmailMessage);

    // Existing submit button logic
    document.getElementById('submit-btn').addEventListener('click', function() {
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value.trim();
      const errorMessage = document.getElementById('error-message');

      // Basic validation
      if (!name || !email || !password) {
        errorMessage.textContent = 'Please fill in all fields.';
        errorMessage.classList.remove('hidden');
        return;
      }

      if (!email.includes('@') || !email.includes('.')) {
        errorMessage.textContent = 'Please enter a valid email address.';
        errorMessage.classList.remove('hidden');
        return;
      }

      if (password.length < 6) {
        errorMessage.textContent = 'Password must be at least 6 characters long.';
        errorMessage.classList.remove('hidden');
        return;
      }

      // Clear error message if validation passes
      errorMessage.classList.add('hidden');

      // Simulate form submission (e.g., log to console)
      console.log('Registration Data:', { name, email, password });
      alert('Registration successful! Check console for submitted data.');
    });

    // Improved fallback detection for animation support
    if (!CSS.supports('animation-name', 'electricCharge')) {
      document.querySelector('.form-container').classList.add('fallback');
      console.log('Animation not supported; fallback static border applied.');
    } else {
      console.log('Rainbow gradient animation applied successfully.');
    }
  