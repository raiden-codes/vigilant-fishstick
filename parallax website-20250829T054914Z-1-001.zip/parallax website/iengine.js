 
   
      // document.getElementById('cta-btn').addEventListener('click', function callme() {
      // window.location.href = 'form.html';
// });
    

    // Fallback for browsers without parallax or animation support
    if (!CSS.supports('background-attachment', 'fixed')) {
      document.querySelectorAll('.parallax').forEach(el => el.classList.add('no-parallax'));
      console.log('Parallax not supported; using scroll fallback.');
    }
    if (!CSS.supports('animation-name', 'electricCharge')) {
      document.querySelector('.rainbow-border').classList.remove('rainbow-border');
      console.log('Rainbow animation not supported; removed rainbow border.');
    } else {
      console.log('Rainbow gradient animation applied successfully.');
    }
  document.getElementById('cta-btn').addEventListener('click', function callme() {
  document.getElementById('form-section').classList.toggle('show');
});