  window.addEventListener('scroll', () => {
      const navbar = document.querySelector('.navbar');
      if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    });
    // Cache DOM elements
    const ctaBtn = document.getElementById('cta-btn');
    const closeBtn = document.getElementById('close-btn');
    const formSection = document.getElementById('form-section');
    const contentContainer = document.getElementById('content-container');
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const submitBtn = document.getElementById('submit-btn');
    const errorMessage = document.getElementById('error-message');
    const nameEmailMessage = document.getElementById('name-email-message');

    // Show form and blur background
    ctaBtn.addEventListener('click', () => {
      formSection.classList.add('show');
      contentContainer.classList.add('blur');
    });

    // Hide form and remove blur
    function hideForm() {
      formSection.classList.remove('show');
      contentContainer.classList.remove('blur');
    }
    closeBtn.addEventListener('click', hideForm);

    // Update name-email message
    function updateNameEmailMessage() {
      const name = nameInput.value.trim();
      const email = emailInput.value.trim();
      if (name) {
        nameEmailMessage.textContent = `Your name email is: ${name}${email ? ' ' + email : ''}`;
        nameEmailMessage.classList.remove('hidden');
      } else {
        nameEmailMessage.classList.add('hidden');
      }
    }
    nameInput.addEventListener('input', updateNameEmailMessage);
    emailInput.addEventListener('input', updateNameEmailMessage);

    // Form submission
    submitBtn.addEventListener('click', () => {
      const name = nameInput.value.trim();
      const email = emailInput.value.trim();
      const password = passwordInput.value.trim();

      if (!name || !email || !password) {
        errorMessage.textContent = 'Please fill in all fields.';
        errorMessage.classList.remove('hidden');
        return;
      }
      if (!email.includes('@') || !email.includes('.')) {
        errorMessage.textContent = 'Please enter a valid email address.';
        errorMessage.classList.remove('hidden');
        return;
      }
      if (password.length < 6) {
        errorMessage.textContent = 'Password must be at least 6 characters long.';
        errorMessage.classList.remove('hidden');
        return;
      }

      errorMessage.classList.add('hidden');
      console.log('Registration Data:', { name, email, password });
      alert('Registration successful! Check console for submitted data.');
      hideForm();
    });

    // Fallback for parallax and animation
    if (!CSS.supports('background-attachment', 'fixed')) {
      document.querySelectorAll('.parallax').forEach(el => el.classList.add('no-parallax'));
      console.log('Parallax not supported; using scroll fallback.');
    }
    if (!CSS.supports('animation', 'electricCharge 1.5s linear infinite')) {
      document.querySelectorAll('.rainbow-border').forEach(el => el.classList.add('fallback'));
      console.log('Rainbow animation not supported; using fallback gradient border.');
    } else {
      console.log('Rainbow gradient animation applied successfully.');
    }
  